require 'spec_helper'

# No specs yet. See http://rspec-puppet.com/
